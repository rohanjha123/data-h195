# Stata2Python

This package takes in Stata commands and outputs their Python equivalents. It currently supports the following commands: -
- ttest (doing a t-test)
- gen (generating new columns)
- describe (describing the data)
- corr (correlation matrix)
- scatter (make a scatter plot)
- hist (make a histogram)
- reg (run a regression)